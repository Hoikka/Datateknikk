
from flask import Flask, render_template, request
from oppslag import Oppslag
from oppslag_reg import OppslagReg

app = Flask(__name__)
@app.route('/')


def oppslag() -> 'html':

    id = request.args.get('id')
    kategori = request.args.get('kategori')

    if kategori:
        if kategori == "hjem":  # Hjem -> viser alle
            with OppslagReg() as db:
                result = db.show_all()
            alle_oppslag = [Oppslag(*x) for x in result]
            return render_template(
                'alle_oppslag.html',
                alle_oppslag=alle_oppslag)

        else:
            with OppslagReg() as db:
                result = db.show_kategori(kategori)
            kategori = [Oppslag(*x) for x in result]
            return render_template('kategori.html', kategori=kategori)

    elif id:
        with OppslagReg() as db:
            db.count_treff(id)
            oppslag = Oppslag(*db.show_oppslag(id))
        return render_template('oppslag.html', oppslag=oppslag)

    else:
        with OppslagReg() as db:
            result = db.show_all()
        alle_oppslag = [Oppslag(*x) for x in result]
        return render_template(
            'alle_oppslag.html',
            alle_oppslag=alle_oppslag)


if __name__ == "__main__":
    app.run(debug=True)
