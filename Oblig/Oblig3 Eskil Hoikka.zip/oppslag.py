class Oppslag:
    def __init__(self, id, kategori, tittel, ingress, oppslagtekst, bruker, dato, treff):
        self.id = id
        self.kategori = kategori
        self.tittel = tittel
        self.ingress = ingress
        self.oppslagstekst = oppslagtekst
        self.bruker = bruker
        self.dato = dato
        self.treff = treff
